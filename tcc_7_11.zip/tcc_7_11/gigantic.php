<?php
include"cabecalho.php";
?>

<h1 class="jogos">Gigantic</h1>
<img class="imagem" src="fotos/gigantic2.jpg">
<section id="jogos">
  <h1 class="text3">Gigantic traz a proposta de um MOBA onde o alvo primordial a ser atacado é um colossal monstro chamado de Guardião, mas ele não ficará parado, irá revidar atacado com toda sua força e sozinho nenhum jogador é capaz de pará-lo. Para isso haverá um time de cinco jogadores que deverão proteger seu guardião e derrotar o guardião inimigo em uma batalha titânica. As opções de personagens são limitadas se comparadas com outros MOBAs, mas cada uma delas possuem grandes diferenças entre si, não tendo assim personagens com ataques semelhantes. Dentre eles há personagens de ataques rápidos, furtivos, portadores de armas de fogo, tankers, magos, atiradores de longo alcance e personagens de ataque físicos de curto alcance. Os Guardiões também são diferentes e possuem modos de ataques, pontos fracos e habilidades diferentes. Eles irão interagir e ajudar na batalha, esmagando adversários em seu caminho. O jogador deve procurar o ponto fraco no guardião inimigo e atacá-lo para vencer a equipe.</h1>
  <section>
    <a class="ui label">
     <strong> ㅤAutor:</strong> ㅤ Gabrielle Dannebrock
   </a>

   <a class="ui label">
     <strong>ㅤ Nota do Autor:</strong>ㅤ9,6
   </a>

   <?php

   if(isset($_GET['cont'])){

    if($_GET['cont']==0 ) {


      echo'
      <a href="gigantic.php?cont=1">

      <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
      <i class="thumbs up outline icon"></i> Like


      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      ';

    }else{
      echo '
      <a href="gigantic.php?cont=0">

      <div class="ui labeled button" tabindex="0">
      <div class="ui blue button">
      <i class="thumbs down outline icon"></i> Deslike

      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>

      ';
    }
  }else{
    $_GET['cont']=0;
  }

  ?>



</div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
<a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
</section>
<br>

<?php
echo"<br> <div class='direita'></div> </div>";
include 'comentario.php';
?>

<?php
include"rodape.php";
?>