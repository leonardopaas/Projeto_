<?php
include"cabecalho.php";
?>


<h1 class="jogos">Paladins</h1>
<img class="imagem" src="fotos/paladins2.jpg">
<section id="jogos">
  <h1 class="text3">Paladins é um shotter em primeira pessoa desenvolvido pelos estúdios Hi-Rez, O jogo usa uma temática fantástica no qual os campeões com que jogamos são paladinos defensores do reino. O jogo é gratis para jogar, toda semana temos alguns campeões abertos para jogar, e com o dinheiro que conseguimos ao vencer partidas podemos habilitar campeões permanentemente para usá-los a qualquer tempo. Os campeões são divididos em 4 tipos: Dano, Flanco, Suporte e Tanquer. O jogo é gratuito para jogar e por isso precisa ganhar dinheiro de alguma forma, no jogo é possível comprar cristais com dinheiro real, e utilizando eles conseguimos comprar campeões e vários itens cosméticos.</h1>

  <section>
    <a class="ui label">
     <strong> ㅤAutor:</strong> ㅤLeonardo Pinheiro
   </a>

   <a class="ui label">
     <strong>ㅤ Nota do Autor:</strong>ㅤ8,0
   </a>

   <?php

   if(isset($_GET['cont'])){

    if($_GET['cont']==0 ) {


      echo'
      <a href="paladins.php?cont=1">

      <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
      <i class="thumbs up outline icon"></i> Like


      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      ';

    }else{
      echo '
      <a href="paladins.php?cont=0">

      <div class="ui labeled button" tabindex="0">
      <div class="ui blue button">
      <i class="thumbs down outline icon"></i> Deslike

      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>

      ';
    }
  }else{
    $_GET['cont']=0;
  }

  ?>

  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
  <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
</section>
<br>

<?php
echo"<br> <div class='direita'></div> </div>";
include 'comentario.php';
?>

<?php
include"rodape.php";
?>