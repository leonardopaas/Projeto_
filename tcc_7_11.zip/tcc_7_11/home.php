<?php
include"cabecalho.php";
?>
<br>
<br>
<br>
<br>
<img src="fotos/mario.png">
<br>
<br>

<h1 class="titulo">
	Moba Arena

</h1>
<h2>Os melhores jogos você encontra aqui!</h2>
<br>
<br>

<br>



<a href="#aqui">

	<div  class="ui huge primary button buttonCat">ㅤㅤJogosㅤㅤ<i class="angle right icon"></i></div>	

	
	<br>
	<br>
	<br>
	<br>

	<br>
	<br>

	<br>
	<br>		
</a>
</div>
</div>

<div id="aqui" class="back">

	<?php
	include"resenhas.php";
	include"rodape.php";
	?>

