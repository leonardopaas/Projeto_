   <?php

   if(isset($_GET['cont'])){

    if($_GET['cont']==0 ) {


      echo'
      <a href="arena.php?cont=1">

      <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
      <i class="thumbs up outline icon"></i> Like


      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      ';
      
    }else{
      echo '
      <a href="arena.php?cont=0">

      <div class="ui labeled button" tabindex="0">
      <div class="ui blue button">
      <i class="thumbs down outline icon"></i> Deslike

      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      
      ';
    }
  }else{
    $_GET['cont']=0;
  }

  ?>