<?php
include"cabecalho.php";
?>

<h1 class="ui horizontal divider header" id="tamCadastro">Recuperar Senha</h1>

<section class="margem">
  <br>
  <form class="ui form">


    <div class="field">
      <h1 class=" fiel text cadResenha1">Digite seu e-mail</h1>
      <div class="two fields">

        <div class="field nome cadBotao">
          <input type="text" name="shipping[last-name]" style="width: 40em" placeholder="E-mail">
        </div>
      </div>
    </div>
    ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ 
    <div class="ui button" tabindex="0"> ㅤ Enviar ㅤ </div>

    <br>

