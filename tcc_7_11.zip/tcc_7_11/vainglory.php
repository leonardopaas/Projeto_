<?php
include"cabecalho.php";
?>


<h1 class="jogos">Vainglory</h1>
<img class="imagem" src="fotos/vainglory.jpg">
<section id="jogos">
  <h1 class="text3">O Vainglory é um jogo multiplayer de arena de batalha online (MOBA) semelhante aos populares MOBAs, como League of Legends e Dota 2, mas projetado para smartphones e tablets, o jogo é uma versão do gênero MOBA em que duas equipes opostas de três ou cinco jogadores lutam para destruir a base inimiga, controlando o caminho entre as bases, que é alinhada por torres e guardada por criaturas inimigas controladas por IA. Fora do caminho, os jogadores lutam pelos pontos de controle que fornecem recursos.Em Vainglory , as equipes têm cinco jogadores, cada um controlando um avatar , conhecido como "herói", de seu próprio dispositivo. Personagens mais fracos controlados por computador , chamados "minions", aparecem nas bases da equipe e seguem as pistas para a base do time adversário, lutando contra inimigos e torres no caminho. O revestimento das pistas são torres de torre que repelem o fluxo de lacaios e heróis inimigos. O objetivo do jogador é destruir as torres inimigas e, finalmente, o "cristal Vão" na base do time inimigo.</h1>

  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ Leonardo Pinheiro
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ9,0
    </a>


   <?php

   if(isset($_GET['cont'])){

    if($_GET['cont']==0 ) {


      echo'
      <a href="vainglory.php?cont=1">

      <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
      <i class="thumbs up outline icon"></i> Like


      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      ';

    }else{
      echo '
      <a href="vainglory.php?cont=0">

      <div class="ui labeled button" tabindex="0">
      <div class="ui blue button">
      <i class="thumbs down outline icon"></i> Deslike

      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>

      ';
    }
  }else{
    $_GET['cont']=0;
  }

  ?>
ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>
  
  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>

    <?php
  include"rodape.php";
  ?>