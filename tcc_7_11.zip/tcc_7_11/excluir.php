<?php
include"cabecalho.php";
?>

<h1 class="ui horizontal divider header" id="tamCadastro">Excluir Resenha</h1>

<section class="margem">
  <br>

  <h1>Tem certeza que deseja excluir está resenha?</h1>
  <br>

  <form class="ui form">
   <div class="field">
    <h1 class=" fiel text cadResenha1">Confirmar senha</h1>
    <div class="two fields">
     ㅤ  ㅤ  ㅤ  ㅤ
     <div class="field nome cadBotao">
      <input type="text" name="shipping[last-name]" style="width: 28em"  placeholder="***********">
    </div>
  </div>
</div>
<br>
ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ 
<div class="ui button " tabindex="0"> ㅤ Excluir  ㅤ </div>
<br>








