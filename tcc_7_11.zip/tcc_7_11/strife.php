<?php
include"cabecalho.php";
?>

<h1 class="jogos">Strife</h1>
<img class="imagem" src="fotos/strife2.jpg">
<section id="jogos">
  <h1 class="text3">Strife é um MOBA com ação 3D, com um elenco colorido de personagens e gráficos de cartoony brilhantes. O jogo possui um sistema de crafting exclusivo e vários outros recursos originais que o diferenciam de outros MOBAs.
  As características mais proeminentes do jogo incluem seu sistema de animais de estimação e crafting. Além de simplesmente selecionar um herói, os jogadores também podem escolher entre mais de uma dúzia de animais de estimação para acompanhá-los na batalha. Cada animal tem 3 habilidades distintas que melhoram o herói do jogador. Qualquer animal de estimação pode ser acompanhado de qualquer campeão. O sistema de criação de itens do jogo permite aos jogadores personalizar os itens disponíveis na loja com as estatísticas que eles desejam.</h1>
  
  <section>
    <a class="ui label">
     <strong> ㅤAutor:</strong> ㅤElisa Fusinato
   </a>

   <a class="ui label">
     <strong>ㅤ Nota do Autor:</strong>ㅤ8,0
   </a>

   <?php

   if(isset($_GET['cont'])){

    if($_GET['cont']==0 ) {


      echo'
      <a href="strife.php?cont=1">

      <div class="ui labeled button" tabindex="0">
      <div class="ui red button">
      <i class="thumbs up outline icon"></i> Like


      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>
      ';

    }else{
      echo '
      <a href="strife.php?cont=0">

      <div class="ui labeled button" tabindex="0">
      <div class="ui blue button">
      <i class="thumbs down outline icon"></i> Deslike

      </div>

      </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
      </a>

      ';
    }
  }else{
    $_GET['cont']=0;
  }

  ?>
  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
  <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
</section>
<br>

<?php
echo"<br> <div class='direita'></div> </div>";
include 'comentario.php';
?>

<?php
include"rodape.php";
?>