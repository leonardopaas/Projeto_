<?php
//include"cabecalho.php";
?>

<br>
<br>
<br>
<br>
<br>
<br>

<div class="esquerda">
  <div class="ui comments">
  <center> <h1 class="ui horizontal divider header branco" id="tamCadastro">Comentário</h1></center>
    <div class="comment">
      <a class="avatar">
        <img src="fotos/usuario4.png">
      </a>
      <div class="content">
        <a class="author branco">Gabrielle</a>
        <div class="metadata">
          <span class="date branco">Hoje às 5:42PM</span>
        </div>
        <div class="text branco">Adorei essa resenha!</div>
        <div class="actions">
          <a class="reply branco">Reply</a>
          <a class="reply branco">Editar</a>
          <a class="reply branco">Excluir</a>
        </div>
      </div>
    </div>
    <div class="comment">
      <a class="avatar">
        <img src="fotos/usuario3.png">
      </a>
      <div class="content">
        <a class="author branco">Elliot Fu</a>
        <div class="metadata">
          <span class="date branco">Ontem às 13:30AM</span>
        </div>
        <div class="text">
          <p class="branco">Isto foi muito útil para a minha pesquisa. Muito obrigado!</p>
        </div>
        <div class="actions">
          <div class="actions">
            <a class="reply branco">Reply</a>
            <a class="reply branco">Editar</a>
            <a class="reply branco">Excluir</a>
          </div>
          <div class="comments">
            <div class="comment">
              <a class="avatar">
                <img src="fotos/usuario1.jpg">
              </a>
              <div class="content">
                <a class="author branco">Jenny Hess</a>
                <div class="metadata">
                  <span class="date branco">Agora</span>
                </div>
                <div class="text branco">Elliot você está sempre tão certo :) </div>
                <div class="actions">
                  <a class="reply branco">Reply</a>
                  <a class="reply branco">Editar</a>
                  <a class="reply branco">Excluir</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="comment">
          <a class="avatar">
            <img src="fotos/usuario3.png">
          </a>
          <div class="content">
            <a class="author branco">Joe Henderson</a>
            <div class="metadata">
              <span class="date branco">5 dias atrás</span>
            </div>
            <div class="text branco">Cara, isso foi impressionante. Muito obrigado </div>
            <div class="actions">
              <a class="reply branco">Reply</a>
              <a class="reply branco">Editar</a>
              <a class="reply branco">Excluir</a>
            </div>
          </div>
        </div>
        <form class="ui reply form">
          <div class="field">
            <textarea></textarea>
          </div>
          <div class="ui blue labeled submit icon button"><i class="icon edit"></i> Responder </div>
        </form>
      </div>
    </div>
  </div>

