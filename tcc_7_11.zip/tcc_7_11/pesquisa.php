<?php
include("cabecalho.php");
include("funcoes.php");


$pesquisa=$_POST['pesquisa'];

$pesquisou=pesquisa($pesquisa);
echo '<a href='.$pesquisou["link"].'>'.$pesquisou["nome"].'</a>';
?>






