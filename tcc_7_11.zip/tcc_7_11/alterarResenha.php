<?php
include"cabecalho.php";
?>


<h1 class="ui horizontal divider header" id="tamCadastro">Alterar Resenha</h1>
<section class="margem">
  <br>
  <form class="ui form">


    <div class="field">
      <h1 class=" fiel text cadResenha1">Título</h1>
      <div class="two fields">

        <div class="field nome cadBotao">
          <input type="text" name="shipping[last-name]" style="width: 40em" placeholder="Título">
        </div>
      </div>
    </div>


    <div class="field">
      <h1 class=" fiel text cadResenha1">Nota do Autor</h1>
      <div class="two fields">

        <div class="field nome">
          <input class="cadBotao" type="text" name="shipping[last-name]" style="width: 40em" placeholder="Nota">
        </div>
      </div>
    </div>

    <div class="field">
      <h1 class=" fiel text cadResenha1">Resenha</h1>
      <div class="two fields">


        <div class="field nome">
          <textarea rows="3" id="mensagem" style="width: 40em"  name="mensagem"></textarea>
        </div>
      </div>
    </div>

    <div class="field">
      <h1 class=" fiel text cadResenha1">Enviar Foto</h1>
      <div class="two fields">

        <div class="field nome ">
          <input type="file" name="arquivo" style="width: 40em" placeholder="Escolher Arquivo">
        </div>
      </div>
    </div>
    <br>
    ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  
    <div class="ui button" tabindex="0">Enviar Alteração</div>
  </div>
</div>


