<?php
function listaResenhas(){
	$resenha= array();

	$dados= file("planilha.csv");

	foreach ($dados as $posicao => $linha) {
		if ($posicao !=0) {
			$colunas= explode(";",$linha);
			$resenha['cod'] =$colunas[0];
			$resenha['resenha'] =$colunas[1];
			$resenha['nome'] =$colunas[2];
			$resenha['imagem'] =$colunas[3];
			$resenha['imagem2'] =$colunas[4];
			$resenha['link'] =$colunas[5];
			$resenhas[]=$resenha;
		}
		
	}
	return $resenhas;
}

//include "listaJogos.php";

function pesquisa($pesquisa){
	//$resenhas = listaJogos();
	/*foreach ($resenhas as $resenha) {
		if($resenha[titulo]==$pesquisa){
			$achado = $resenha;
			break;
		}
	}*/

	$resenhas=listaResenhas();
	// print($pesquisa);
	

	for ($i=0; $i < 12 ; $i++) { 
	// print_r($resenhas[$i]['nome']);
		if ($resenhas[$i]['nome']==$pesquisa) {
			$achado=$resenhas[$i];
		}
	}
	return $achado;
}

