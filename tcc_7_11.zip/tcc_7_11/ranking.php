<?php
include"cabecalho.php";
?>

<h1 class="ui horizontal divider header" id="tamCadastro">Resenhas mais Acessadas</h1>

<br>
<br>
<br>

<div class="ui grid center aligned page grid">

	<br>
	<div class="five wide column">

		<div class="ui special cards">
			<div class="card">

				<div class="dimmable image">
					<div class="ui dimmer">
						<div class="content">
						</div>
					</div>
					<img src="fotos/lol1.jpg">
				</div>
				<div class="content">
					<a class="header" href="lol.php">League Of Legends</a>
					<div class="ui star rating" data-rating="4"></div>

				</div>
			</div>
		</div>
	</div>
	</a>

	<br>
	<div class="five wide column">

		<div class="ui special cards">
			<div class="card">

				<div class="dimmable image">
					<div class="ui dimmer">
						<div class="content">
						</div>
					</div>
					<img src="fotos/heroes2.jpg">

				</div>
				<div class="content">
					<a class="header" href="heroes.php">Heroes Of The Storm</a>
					<div class="ui star rating" max-rating-data="5" data-rating="4"></div>
				</div>
			</div>
		</div>
	</div>

	<br>
	<div class="five wide column">

		<div class="ui special cards">
			<div class="card">

				<div class="dimmable image">
					<div class="ui dimmer">
						<div class="content">
						</div>
					</div>
					<img src="fotos/smite2.jpg">

				</div>
				<div class="content">
					<a class="header" href="smite.php">Smite</a>
					<div class="ui star rating" max-rating-data="5" data-rating="3"></div>
				</div>
			</div>
		</div>
	</div>


	<br>
	<div class="five wide column">

		<div class="ui special cards">
			<div class="card">

				<div class="dimmable image">
					<div class="ui dimmer">
						<div class="content">
						</div>
					</div>
					<img src="fotos/dota.jpg">
				</div>
				<div class="content">
					<a class="header" href="dota.php">Dota 2</a>
					<div class="ui star rating" max-rating-data="5" data-rating="3"></div>
				</div>
			</div>
		</div>
	</div>


	<br>
	<div class="five wide column">

		<div class="ui special cards">
			<div class="card">

				<div class="dimmable image">
					<div class="ui dimmer">
						<div class="content">
						</div>
					</div>
					<img src="fotos/vainglory2.jpg">

				</div>
				<div class="content">
					<a class="header" href="vainglory.php">Vainglory</a>
					<div class="ui star rating" max-rating-data="5" data-rating="2"></div>
					<br>					
				</div>
			</div>
		</div>
	</div>


	<br>
	<div class="five wide column">

		<div class="ui special cards">
			<div class="card">

				<div class="dimmable image">
					<div class="ui dimmer">
						<div class="content">
						</div>
					</div>
					<img src="fotos/arena2.jpg">

				</div>
				<div class="content">
					<a class="header" href="arena.php">Arena Of Valor</a>
					<div class="ui star rating" max-rating-data="5" data-rating="1"></div>					
				</div>
			</div>
		</div>
	</div>


	<?php
	include"rodape.php";
	?>


