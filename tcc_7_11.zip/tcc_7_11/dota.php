<?php
include"cabecalho.php";
?>
<h1 class="jogos">Dota 2</h1>
<img class="imagem" src="fotos/dota1.jpg">
<section id="jogos">
  <h1 class="text3">Dota 2, o famoso MOBA desenvolvido pela Valve e baseado na modificação de warcraft 3, é um jogo em eterna mutação. Seja pela adição de novos heróis, um buff que altera drasticamente o game ou até mesmo eventos especiais, sempre há uma atualização inédita para se explorar. Mesmo com tantas alterações, o game continua tão divertido quanto em seu lançamento. Confira o review completo. A narrativa nunca foi o foco de Dota 2 e até hoje isso permanece verdadeiro. A trama consiste em duas facções (os Iluminados e os Temidos) em eterna guerra para destruir o ancião do time oposto. Até mesmo essa premissa básica não é explorada no jogo, que deixa o gameplay falar por si só. Aqueles que buscam mais informações devem recorrer às descrições de cada personagem, assim como wikis do jogo para entender melhor a história, o que não é ideal.</h1>

  <section>
    <a class="ui label">
      <strong> ㅤAutor:</strong> ㅤ Aline Soster
    </a>

    <a class="ui label">
      <strong>ㅤ Nota do Autor:</strong>ㅤ8,5
    </a>
    <?php

    if(isset($_GET['cont'])){

      if($_GET['cont']==0 ) {


        echo'
        <a href="dota.php?cont=1">

        <div class="ui labeled button" tabindex="0">
        <div class="ui red button">
        <i class="thumbs up outline icon"></i> Like


        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>
        ';

      }else{
        echo '
        <a href="dota.php?cont=0">

        <div class="ui labeled button" tabindex="0">
        <div class="ui blue button">
        <i class="thumbs down outline icon"></i> Deslike

        </div>

        </div>  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ  ㅤ
        </a>

        ';
      }
    }else{
      $_GET['cont']=0;
    }

    ?>
    <a href="denuncia.php"><i class="exclamation triangle icon"></i>Denunciar</a>
  </section>
  <br>

  <?php
  echo"<br> <div class='direita'></div> </div>";
  include 'comentario.php';
  ?>

  <?php
  include"rodape.php";
  ?>