<?php

if(isset($_GET['cont'])){

		if($_GET['cont']==0 ) {

			echo'
			<a href="detalha_resenha.php?cod='.$codigo.'&cont=1">
			<input type="button" value="curtir">
			</a>

			';

		}else{
			echo '

			Você já curtiu essa resenha!
			<a href="Dresenha.php?cod='.$codigo.'&cont=0">
			<input type="button" value="remova sua cutida">
			</a>
			';
		}
		}else{
			$_GET['cont']=0;
		}
}
?>